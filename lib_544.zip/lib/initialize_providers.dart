// import 'package:petty_cash/resources/theme/theme_provider.dart';

// import 'package:petty_cash/view_model/auth_vm/lead_authvm.dart';

// import 'package:petty_cash/view_model/home_module_vm/dashboard_vm.dart';

// import 'package:provider/provider.dart';
// import 'package:provider/single_child_widget.dart';

// class AppProviders {
//   static List<SingleChildWidget> allProviders = [
//     ChangeNotifierProvider(create: (_) => ThemeProvider()),
//     ChangeNotifierProvider(create: (_) => LeadAuthVm()),
//     ChangeNotifierProvider(create: (_) => DashboardVm()),
//   ];
// }
