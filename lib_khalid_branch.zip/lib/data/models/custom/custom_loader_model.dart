class CustomLoaderModel {
  final int index;
  bool isSelected;

  CustomLoaderModel({
    required this.index,
    this.isSelected = false,
  });
}
