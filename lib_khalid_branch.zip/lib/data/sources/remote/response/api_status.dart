enum ApiStatus { LOADING, COMPLETED, ERROR }
